COREBTR QBank — static hosting package

Contents:
- index.html: your original QBank HTML, kept intact
- vercel.json: minimal static-site configuration

Deploy:
1. Extract this ZIP on a computer.
2. Put the extracted folder in a GitHub repository.
3. In Vercel, choose Add New -> Project and import that repository.
4. Leave Framework Preset as Other.
5. Leave Build Command and Output Directory empty/default; deploy the static files.
6. Open the generated HTTPS URL in Chrome.

Important video note:
HTTPS hosting removes the file:// origin limitation and gives the page a normal web origin.
It does NOT bypass DRM or guarantee video playback. The HTML references DRM-protected
Gumlet DASH/HLS streams and Shaka Player. Playback still depends on the provider's valid
authorization/license, browser DRM support, and the media server's CORS policy. If Error
6002 remains after hosting, the video provider must correct/allow the site's HTTPS origin
and confirm that the account/content is authorized for playback.

The HTML was packaged without changing the question bank or its video/DRM logic.
